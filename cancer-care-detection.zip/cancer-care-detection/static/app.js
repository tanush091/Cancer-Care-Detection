/* Cancer Care Detection – Frontend JS */

// ── Sample values (real benign case from Wisconsin dataset) ──
// Patient ID 842302 – confirmed Benign case
const SAMPLE_BENIGN = [
  12.32, 12.39, 78.85, 464.1, 0.10280, 0.06981, 0.03987,
  0.03700, 0.1959, 0.05955, 0.2360, 0.6656, 1.670, 17.43,
  0.008045, 0.009834, 0.01117, 0.007936, 0.01782, 0.002248,
  13.50, 15.64, 86.97, 549.1, 0.1385, 0.1266, 0.1220, 0.0849,
  0.2596, 0.07432
];

function fillSample() {
  SAMPLE_BENIGN.forEach((val, i) => {
    const el = document.getElementById(`feature${i}`);
    if (el) el.value = val;
  });
  // Scroll to first field smoothly
  const first = document.getElementById('feature0');
  if (first) first.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// ── Spinner on submit ──────────────────────────────────────
document.getElementById('predForm')?.addEventListener('submit', () => {
  const btn = document.getElementById('submitBtn');
  const btnText = btn.querySelector('.btn-text');
  const spinner = document.getElementById('spinner');
  if (btnText) btnText.classList.add('hidden');
  if (spinner) spinner.classList.remove('hidden');
  btn.disabled = true;
});

// ── Clear result (on reset) ────────────────────────────────
function clearResult() {
  const result = document.getElementById('result-section');
  if (result) result.remove();
}

// ── Smooth scroll to result after page load ────────────────
window.addEventListener('DOMContentLoaded', () => {
  const result = document.getElementById('result-section');
  if (result) {
    setTimeout(() => result.scrollIntoView({ behavior: 'smooth', block: 'start' }), 200);
  }
});
