"""
Cancer Care Detection – Flask Web Application
Run: python app.py
Then open: http://127.0.0.1:5000
"""
from flask import Flask, render_template, request, jsonify
import numpy as np
import pickle
import os
import sys

app = Flask(__name__)

# ── Load saved model artefacts ───────────────────────────────
MODEL_DIR = os.path.join(os.path.dirname(__file__), "model")

def load_model_artifacts():
    """Load model, scaler, and feature names from disk with clear error messages."""
    required = ["cancer_model.pkl", "scaler.pkl", "feature_names.pkl"]
    for fname in required:
        fpath = os.path.join(MODEL_DIR, fname)
        if not os.path.exists(fpath):
            print(f"\n  [ERROR] Missing model file: {fpath}")
            print("  Please run:  python train_model.py  first to generate the model files.\n")
            sys.exit(1)

    with open(os.path.join(MODEL_DIR, "cancer_model.pkl"), "rb") as f:
        model = pickle.load(f)
    with open(os.path.join(MODEL_DIR, "scaler.pkl"), "rb") as f:
        scaler = pickle.load(f)
    with open(os.path.join(MODEL_DIR, "feature_names.pkl"), "rb") as f:
        feature_names = pickle.load(f)

    return model, scaler, feature_names

model, scaler, feature_names = load_model_artifacts()
NUM_FEATURES = len(feature_names)   # 30 for Wisconsin dataset

# ── Routes ───────────────────────────────────────────────────
@app.route("/")
def home():
    return render_template("index.html", feature_names=feature_names)


@app.route("/predict", methods=["POST"])
def predict():
    try:
        features = [float(request.form[f"feature{i}"]) for i in range(NUM_FEATURES)]
        arr = np.array(features).reshape(1, -1)
        arr_scaled = scaler.transform(arr)

        pred  = model.predict(arr_scaled)[0]
        proba = model.predict_proba(arr_scaled)[0]

        # Wisconsin dataset: target 0 = Malignant, 1 = Benign
        if pred == 0:
            result  = "Malignant"
            message = "⚠️ Tumour detected as Malignant (Cancerous). Please consult a doctor immediately."
            risk    = round(proba[0] * 100, 2)   # probability of class 0 (Malignant)
            badge   = "danger"
        else:
            result  = "Benign"
            message = "✅ Tumour detected as Benign (Non-Cancerous). Regular check-ups recommended."
            risk    = round(proba[1] * 100, 2)   # probability of class 1 (Benign)
            badge   = "safe"

        return render_template(
            "index.html",
            feature_names=feature_names,
            prediction=result,
            message=message,
            confidence=risk,
            badge=badge,
            user_values={f"feature{i}": request.form.get(f"feature{i}", "") for i in range(NUM_FEATURES)},
        )

    except KeyError as e:
        return render_template("index.html", feature_names=feature_names,
                               error=f"Missing input field: {e}. Please fill in all 30 features.")
    except ValueError as e:
        return render_template("index.html", feature_names=feature_names,
                               error=f"Invalid number entered: {e}. All fields must be numeric.")
    except Exception as e:
        return render_template("index.html", feature_names=feature_names, error=str(e))


# ── REST API endpoint (optional / Postman / cURL) ───────────
@app.route("/api/predict", methods=["POST"])
def api_predict():
    try:
        body     = request.get_json(force=True)
        if "features" not in body:
            return jsonify({"error": "Request body must contain a 'features' list."}), 400
        features = body["features"]
        if len(features) != NUM_FEATURES:
            return jsonify({"error": f"Expected {NUM_FEATURES} features, got {len(features)}."}), 400
        arr   = np.array(features, dtype=float).reshape(1, -1)
        arr_s = scaler.transform(arr)
        pred  = model.predict(arr_s)[0]
        proba = model.predict_proba(arr_s)[0].tolist()
        return jsonify({
            "prediction":  "Malignant" if pred == 0 else "Benign",
            "probability": {"malignant": round(proba[0], 4), "benign": round(proba[1], 4)},
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400


if __name__ == "__main__":
    print("\n  [*] Cancer Care Detection App running at http://127.0.0.1:5000\n")
    app.run(debug=True)
