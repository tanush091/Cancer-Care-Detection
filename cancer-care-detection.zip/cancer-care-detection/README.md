# Cancer Care Detection System

AI-powered Breast Cancer Detection web app using Flask + Scikit-Learn.

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Train and save the model (run once)
```bash
python train_model.py
```

### 3. Start the web application
```bash
python app.py
```

### 4. Open your browser
```
http://127.0.0.1:5000
```

## Project Structure
```
cancer-care-detection/
├── app.py              ← Flask web application
├── train_model.py      ← Train & save the ML model
├── requirements.txt    ← Python dependencies
├── Procfile            ← Deployment (Render/Heroku)
├── model/
│   ├── cancer_model.pkl   ← Trained Random Forest model
│   ├── scaler.pkl         ← StandardScaler
│   └── feature_names.pkl  ← Feature name labels
├── templates/
│   └── index.html      ← Frontend GUI
└── static/
    ├── style.css        ← Styles
    └── app.js           ← Frontend JavaScript
```

## API Usage (Postman / curl)
```bash
curl -X POST http://127.0.0.1:5000/api/predict \
  -H "Content-Type: application/json" \
  -d '{"features": [13.54,14.36,87.46,566.3,0.0978,0.0813,0.0666,0.0478,0.1885,0.0577,0.27,0.79,2.06,23.6,0.0085,0.0146,0.0239,0.0132,0.0198,0.0023,15.11,19.26,99.7,711.2,0.144,0.177,0.239,0.129,0.298,0.073]}'
```

## Dataset
Wisconsin Breast Cancer Dataset – 569 samples, 30 features.

| Target | Label |
|--------|-------|
| 0      | Malignant (Cancerous) |
| 1      | Benign (Non-Cancerous) |

## Model Performance
- Algorithm: Random Forest (200 estimators)
- Accuracy: ~97–99%
- Metric focus: Recall (to minimize false negatives)
